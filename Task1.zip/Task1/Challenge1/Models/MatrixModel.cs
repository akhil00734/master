﻿namespace Challenge1.Models
{
    public class MatrixModel
    {
        public int[,] Matrix { get; set; }

    }
}

