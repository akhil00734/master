﻿namespace Challenge1.Models
{
    public class Groups
    {
        public int NumberOfGroups { get; set; }
    }
}
