﻿using Challenge1.Models;
namespace Challenge1.Services
{
    public class PatientService : IPatientService
    {
        private static int ROW;
        private static int COL;
        public Groups Calculate(MatrixModel matModel)
        {
            Groups model = new Groups();
            ROW = matModel.Matrix.GetLength(0);
            COL = matModel.Matrix.GetLength(1);

            model.NumberOfGroups = CountIslands(matModel.Matrix);

            return model;
        }


        #region private methods

        private int CountIslands(int[,] mat)
        {
            bool[,] visited = new bool[ROW, COL];

            int count = 0;

            for (int i = 0; i < ROW; i++)
            {
                for (int j = 0; j < COL; j++)
                {
                    if (mat[i, j] == 1 && !visited[i, j])
                    {
                        Dfs(mat, i, j, visited);
                        count++;
                    }
                }
            }

            return count;
        }

        // the 8 patients as adjacent vertices
        private void Dfs(int[,] mat, int x, int y, bool[,] visited)
        {
            visited[x, y] = true;

            if (IfSafe(mat, x - 1, y - 1, visited))
            {
                Dfs(mat, x - 1, y - 1, visited);
            }

            if (IfSafe(mat, x - 1, y, visited))
            {
                Dfs(mat, x - 1, y, visited);
            }

            if (IfSafe(mat, x - 1, y + 1, visited))
            {
                Dfs(mat, x - 1, y + 1, visited);
            }

            if (IfSafe(mat, x, y - 1, visited))
            {
                Dfs(mat, x, y - 1, visited);
            }

            if (IfSafe(mat, x, y + 1, visited))
            {
                Dfs(mat, x, y + 1, visited);
            }

            if (IfSafe(mat, x + 1, y - 1, visited))
            {
                Dfs(mat, x + 1, y - 1, visited);
            }

            if (IfSafe(mat, x + 1, y, visited))
            {
                Dfs(mat, x + 1, y, visited);
            }

            if (IfSafe(mat, x + 1, y + 1, visited))
            {
                Dfs(mat, x + 1, y + 1, visited);
            }

        }
        // Base condition
        private bool IfSafe(int[,] mat, int x, int y, bool[,] visited)
        {
            return x >= 0 && x < ROW
                && y >= 0 && y < COL
                && mat[x, y] == 1
                && !visited[x, y];
        }
        #endregion

    }
}
