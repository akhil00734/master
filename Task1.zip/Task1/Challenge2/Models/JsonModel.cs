﻿namespace Challenge2.Models
{
    public class JsonModel
    {
        public string Login { get; set; }
        public int Id { get; set; }
        public string Node_id { get; set; }
        public string Url { get; set; }
        public string Repos_Url { get; set; }
        public string Events_Url { get; set; }
        public string Hooks_Url { get; set; }
        public string Issues_Url { get; set; }
        public string Members_Url { get; set; }
        public string Public_Members_Url { get; set; }
        public string Avatar_Url { get; set; }
        public string Description { get; set; }
    }
}
