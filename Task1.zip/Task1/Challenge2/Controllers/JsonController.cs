﻿using Challenge2.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;
using System.Net;

namespace Challenge2.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class JsonController : ControllerBase
    {       
        
        [HttpGet]
        public IEnumerable<JsonModel> Get()
        {
             var webClient = new WebClient();

            /* Given webUrl thowing forbidden(403) error. If I access the data from Code. 
             * So created a json in the directory with the same data available in the url. */

            var jsonData = webClient.DownloadString(@"data.json");
            List<JsonModel> model = JsonConvert.DeserializeObject<List<JsonModel>>(jsonData);           

            // Finding Max and Min values using linq
            var maxValue = model.Max(s => s.Id);
            var minValue = model.Min(s => s.Id);

            //Fetching Minimum and Maximum Id data using linq
            IEnumerable<JsonModel> result = from mod in model where mod.Id >= maxValue || mod.Id <= minValue
                                     select new JsonModel
                                     {
                                         Id = mod.Id,
                                         Login = mod.Login,
                                         Node_id = mod.Node_id,
                                         Events_Url = mod.Events_Url,
                                         Hooks_Url = mod.Hooks_Url,
                                         Members_Url = mod.Members_Url,
                                         Repos_Url = mod.Repos_Url,
                                         Public_Members_Url = mod.Public_Members_Url,
                                         Issues_Url = mod.Issues_Url,
                                         Url = mod.Url,
                                         Avatar_Url = mod.Avatar_Url,
                                         Description = mod.Description
                                      };

            return result;
          

        }
    }
}
